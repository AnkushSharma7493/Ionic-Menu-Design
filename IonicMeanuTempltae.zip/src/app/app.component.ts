import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  
  selectedMenu : number=0;

  constructor() {}


  setMenu(menu:number){
    this.selectedMenu=menu;
  }

}
