import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DeliveryManListPage } from './delivery-man-list.page';

const routes: Routes = [
  {
    path: '',
    component: DeliveryManListPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DeliveryManListPageRoutingModule {}
