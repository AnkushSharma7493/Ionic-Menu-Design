import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DeliveryManListPageRoutingModule } from './delivery-man-list-routing.module';

import { DeliveryManListPage } from './delivery-man-list.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DeliveryManListPageRoutingModule
  ],
  declarations: [DeliveryManListPage]
})
export class DeliveryManListPageModule {}
