import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivery-man-list',
  templateUrl: './delivery-man-list.page.html',
  styleUrls: ['./delivery-man-list.page.scss'],
})
export class DeliveryManListPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
