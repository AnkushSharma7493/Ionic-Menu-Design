import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DeliveryManDetailsPageRoutingModule } from './delivery-man-details-routing.module';

import { DeliveryManDetailsPage } from './delivery-man-details.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DeliveryManDetailsPageRoutingModule
  ],
  declarations: [DeliveryManDetailsPage]
})
export class DeliveryManDetailsPageModule {}
