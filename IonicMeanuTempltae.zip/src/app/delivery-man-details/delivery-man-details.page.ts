import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivery-man-details',
  templateUrl: './delivery-man-details.page.html',
  styleUrls: ['./delivery-man-details.page.scss'],
})
export class DeliveryManDetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
