import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DeliveryManDetailsPage } from './delivery-man-details.page';

const routes: Routes = [
  {
    path: '',
    component: DeliveryManDetailsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DeliveryManDetailsPageRoutingModule {}
