import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-refer-nearn',
  templateUrl: './refer-nearn.page.html',
  styleUrls: ['./refer-nearn.page.scss'],
})
export class ReferNEarnPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
