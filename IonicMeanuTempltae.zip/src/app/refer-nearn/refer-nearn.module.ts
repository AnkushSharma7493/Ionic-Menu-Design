import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ReferNEarnPageRoutingModule } from './refer-nearn-routing.module';

import { ReferNEarnPage } from './refer-nearn.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReferNEarnPageRoutingModule
  ],
  declarations: [ReferNEarnPage]
})
export class ReferNEarnPageModule {}
