import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ReferNEarnPage } from './refer-nearn.page';

const routes: Routes = [
  {
    path: '',
    component: ReferNEarnPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ReferNEarnPageRoutingModule {}
